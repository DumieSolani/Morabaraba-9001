﻿using System;

namespace Morabaraba.Test
{
    public class Class1
    {
    }
}
